
function Main()
{
  return(
    <div>
      This is the main
    </div>
  )
}

export default Main;