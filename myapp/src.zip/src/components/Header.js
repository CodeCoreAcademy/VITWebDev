function Header()
{
  return(
    <div>
      This is a header
    </div>
  )
}

export default Header;