function Footer()
{
  return(
    <div>
      This is footer
    </div>
  )
}

export default Footer;